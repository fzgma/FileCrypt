FileCrypt directory round-trip test corpus
===========================================

Purpose: exercise recursive directory encryption/decryption and verify the recovered files.
The archive contains random binary payloads, zero-length files, Unicode names and contents,
nested directories, structured text, and filenames with spaces and punctuation.

Verification: after extracting and decrypting the directory, compare every file against
manifest.sha256. The manifest lists SHA-256 and byte size for every file except itself.
Use a binary-safe comparison for the .bin files.

Generated on: 2026-10-10 UTC
